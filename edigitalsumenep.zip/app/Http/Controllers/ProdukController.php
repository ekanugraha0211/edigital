<?php

namespace App\Http\Controllers;

use App\Models\produk;
use Illuminate\Http\Request;

class ProdukController extends Controller
{
    // public function index()
    // {
    //     // $produk= produk::get();
    //     $produk = Produk::with('umkm')->get();
    //     $title = 'produk';
    //     return view('produk', compact('produk','title'));
    // }
    public function index()
    {
        // $title = ucfirst($sektor);
        $title = 'produk';
        $produk = Produk::with('umkm')
            ->whereHas('umkm.sektorUsaha', function ($query) use ($sektor) {
                $query->where('nama', $sektor);
            });

        if ($request->has('search') && $request->search != '') {
            $produk->where(function($query) use ($request) {
                $query->where('nama_produk', 'like', '%' . $request->search . '%')
                      ->orWhere('tagline', 'like', '%' . $request->search . '%')
                      ->orWhere('deskripsi', 'like', '%' . $request->search . '%')
                      ->orWhereHas('umkm', function($query) use ($request) {
                          $query->where('nama', 'like', '%' . $request->search . '%')
                                ->orWhere('alamat', 'like', '%' . $request->search . '%')
                                ->orWhere('desa', 'like', '%' . $request->search . '%')
                                ->orWhere('kecamatan', 'like', '%' . $request->search . '%');
                      });
            });
        }
        
        

        $produk = $produk->paginate(9);

        return view('produk', compact('produk', 'title'));
    }
    public function show(produk $produk)
    {
        $title = 'produk';
        return view('produk_detail',['produk' => $produk, 'title' => $title]);
    }
}
