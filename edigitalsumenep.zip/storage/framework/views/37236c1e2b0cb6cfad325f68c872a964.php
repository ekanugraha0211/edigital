
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Pertanyaan dan Jawaban</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="/admin">Home</a></li>
              <li class="breadcrumb-item active">Bantuan</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <?php if(session('success')): ?>
          <div class="alert alert-success">
              <?php echo e(session('success')); ?>

          </div>
        <?php endif; ?>
        <form action="<?php echo e(route('adminBantuan.updateAll')); ?>" method="post" enctype="multipart/form-data">
          <?php echo csrf_field(); ?>
          <?php echo method_field('put'); ?>
          <div class="row">
              <div class="col-md-12">
                  <div class="card card-primary">
                      <div class="card-header">
                          <h3 class="card-title">List QnA</h3>
                          <div class="card-tools">
                              <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                                  <i class="fas fa-minus"></i>
                              </button>
                          </div>
                      </div>

                      <?php $__currentLoopData = $bantuan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <div class="card-body">
                              <input type="hidden" name="ids[]" value="<?php echo e($b->id); ?>">
                              <div class="form-group">
                                  <label for="pertanyaan_<?php echo e($b->id); ?>">Pertanyaan</label>
                                  <input type="text" id="pertanyaan_<?php echo e($b->id); ?>" name="pertanyaan[<?php echo e($b->id); ?>]" class="form-control" value="<?php echo e($b->pertanyaan); ?>">
                              </div>
                              <div class="form-group">
                                  <label for="jawaban_<?php echo e($b->id); ?>">Jawaban</label>
                                  <textarea id="jawaban_<?php echo e($b->id); ?>" name="jawaban[<?php echo e($b->id); ?>]" class="form-control" rows="5"><?php echo e($b->jawaban); ?></textarea>
                              </div>
                          </div>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                      <!-- /.card-body -->
                  </div>
                  <!-- /.card -->
              </div>  
          </div>
          <div class="row">
            <div class="col-12">
              <input type="submit" value="Simpan" class="btn btn-success float-right">
            </div>
          </div>
        </form>
    </section>
    <!-- /.content -->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\edigitalsumenep\resources\views/admin/bantuan.blade.php ENDPATH**/ ?>