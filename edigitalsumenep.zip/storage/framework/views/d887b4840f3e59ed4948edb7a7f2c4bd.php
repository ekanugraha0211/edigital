
<?php $__env->startSection('content'); ?>
<?php
use Illuminate\Support\Facades\Auth;
// $user = Auth::user();
?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Beranda UMKM</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="/umkm">Home</a></li>
              
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <!-- Info boxes -->
        
        <!-- /.row -->

       

        <!-- Main row -->
        <div class="row">
          <!-- Left col -->
          <div class="col-md-8">
            <!-- MAP & BOX PANE -->
            
            <div class="row">
              

              <div class="col-md-12">
                <!-- USERS LIST -->
                
                <!--/.card -->
              </div>
              <!-- /.col -->
            </div>
            <!-- /.row -->

            <!-- TABLE: LATEST ORDERS -->
            
            <!-- /.card -->
          </div>
          <div class="col-md-12">
            <!-- Info Boxes Style 2 -->
            <div class="info-box mb-3 bg-warning">
              <span class="info-box-icon"><i class="fas fa-chart-bar"></i></span>

              <div class="info-box-content">
                <span class="info-box-text">Skala Usaha</span>
                <span class="info-box-number"><?php echo e($skala->count()); ?></span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
            <div class="info-box mb-3 bg-success">
              <span class="info-box-icon"><i class="fas fa-plane"></i></span>

              <div class="info-box-content">
                <span class="info-box-text">Sektor Usaha</span>
                <span class="info-box-number"><?php echo e($sektor->count()); ?></span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
            <div class="info-box mb-3 bg-danger">
              <span class="info-box-icon"><i class="fas fa-shapes"></i></span>

              <div class="info-box-content">
                <span class="info-box-text">Bentuk Usaha</span>
                <span class="info-box-number"><?php echo e($bentuk->count()); ?></span>
              </div>
              <!-- /.info-box-content -->
            </div>
            
            </div>
            <!-- /.info-box -->

          

            <!-- PRODUCT LIST -->
          
          </div>
          <!-- /.col -->
          
          <!-- /.col -->

         
        </div>
        <!-- /.row -->
      </div><!--/. container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <script>
  new DataTable('#example', {
    layout: {
        bottomEnd: {
            paging: {
                boundaryNumbers: false
            }
        }
    }
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('customer.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\edigitalsumenep\resources\views/customer/konten.blade.php ENDPATH**/ ?>