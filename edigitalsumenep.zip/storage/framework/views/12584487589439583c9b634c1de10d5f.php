
<?php $__env->startSection('container'); ?>
  <main id="main">

    <!-- ======= Breadcrumbs ======= -->
    <div class="breadcrumbs">
      <div class="page-header d-flex align-items-center" style="background-image: url('');">
        <div class="container position-relative">
          <div class="row d-flex justify-content-center">
            <div class="col-lg-6 text-center">
              <h2>Produk Kuliner</h2>
              <p>Selamat datang di halaman produk kuliner! Di sini, Anda akan menemukan beragam produk UMKM lokal dari kategori kuliner di Sumenep. Dari makanan ringan hingga makanan siap saji, setiap produk kami menampilkan keunikan dan kualitas yang berasal dari para pengusaha kecil Sumenep. Selamat menelusuri pilihan kuliner khas Sumenep yang menggugah selera!</p>
            </div>
          </div>
        </div>
      </div>
      <nav>
        <div class="container">
          <ol>
            <li><a href="/">Beranda</a></li>
            <li>Kuliner</li>
          </ol>
        </div>
      </nav>
    </div>
    <div class="portfolio-flters d-flex flex-row justify-content-center">
      <!-- Input pencarian menggunakan komponen form Bootstrap -->
      <input id="search-input" class="form-control me-2 w-75"  type="search" placeholder="Cari Produk" aria-label="Search">
    </select>
      <button id="search-button" class="btn btn-success" type="button">Cari</button>
  </div><!-- End Breadcrumbs -->

    <!-- ======= Blog Section ======= -->
    <section id="blog" class="blog">
      <div class="container" data-aos="fade-up">

        <div class="row gy-4 posts-list">
          <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($p->umkm->id_sektor_usaha == '1'): ?>
          <div class="col-xl-4 col-md-6">
            <article>
              <div class="post-img">
                <img src="<?php echo e($p->foto); ?>" alt="" class="img-fluid">
              </div>
              <p class="post-category"><?php echo e($p->umkm->SektorUsaha->nama); ?></p>
              <h2 class="title">
              <a href="/detail"><?php echo e($p->tagline); ?></a>
              </h2>
              <div class="d-flex align-items-center">
                <img src="<?php echo e($p->umkm->logo); ?>" alt="" class="img-fluid post-author-img flex-shrink-0">
                <div class="post-meta">
                  <p class="post-author-list"><?php echo e($p->umkm->nama); ?></p>
                  <!-- <p class="post-date">
                    <time datetime="2022-01-01">Jan 1, 2022</time>
                  </p> -->
                </div>
              </div>
            </article>
          </div>
          <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <!-- End post list item -->
        </div><!-- End blog posts list -->
        
        <div class="blog-pagination">
          <ul class="pagination justify-content-center">
              
              <?php if($produk->onFirstPage()): ?>
                  <li class="page-item disabled"><span class="page-link">&laquo;</span></li>
              <?php else: ?>
                  <li class="page-item"><a href="<?php echo e($produk->previousPageUrl()); ?>" class="page-link" rel="prev">&laquo;</a></li>
              <?php endif; ?>
      
              
              <?php for($i = 1; $i <= $produk->lastPage(); $i++): ?>
                  <?php if($i == $produk->currentPage()): ?>
                      <li class="page-item active"><span class="page-link bg-success"><?php echo e($i); ?></span></li>
                  <?php else: ?>
                      <li class="page-item"><a href="<?php echo e($produk->url($i)); ?>" class="page-link"><?php echo e($i); ?></a></li>
                  <?php endif; ?>
              <?php endfor; ?>
      
              
              <?php if($produk->hasMorePages()): ?>
                  <li class="page-item"><a href="<?php echo e($produk->nextPageUrl()); ?>" class="page-link" rel="next">&raquo;</a></li>
              <?php else: ?>
                  <li class="page-item disabled"><span class="page-link ">&raquo;</span></li>
              <?php endif; ?>
          </ul>
      </div>
    </section><!-- End Blog Section -->

  </main>
  
<!-- End #main -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\edigitalsumenep\resources\views/produkSektor/Kreatif.blade.php ENDPATH**/ ?>