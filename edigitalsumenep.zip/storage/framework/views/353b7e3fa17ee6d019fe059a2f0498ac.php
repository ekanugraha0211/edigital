
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    
      <section class="content-header">
      
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>User Edit</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">User</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>
<form action="<?php echo e(route('User.update',$user->id)); ?>" method="post" enctype="multipart/form-data">
  <?php echo csrf_field(); ?>
  <?php echo method_field('put'); ?>
      <div class="row">
        <div class="col-md-12">
          <div class="card card-primary">
            <div class="card-header">
              <h3 class="card-title">User</h3>

              <div class="card-tools">
                <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                  <i class="fas fa-minus"></i>
                </button>
              </div>
            </div>
            <div class="card-body">
                <div class="form-group">
                  <label for="name">Name</label>
                  <input type="text" id="name" name="name" class="form-control" value="<?php echo e($user->name); ?>">
              </div>
                <div class="form-group">
                  <label for="email">Email</label>
                  <input type="email" id="email" name="email" class="form-control" value="<?php echo e($user->email); ?>">
              </div>
              <div class="form-group">
                <label for="role">Status</label>
                <div class="form-check">
                    <input type="radio" id="umkm" name="role" class="form-check-input" value="umkm" <?php echo e($user->role == 'umkm' ? 'checked' : ''); ?>>
                    <label class="form-check-label" for="umkm">Aktif</label>
                </div>
                <div class="form-check">
                    <input type="radio" id="guest" name="role" class="form-check-input" value="Guest" <?php echo e($user->role == 'Guest' ? 'checked' : ''); ?>>
                    <label class="form-check-label" for="guest">Nonaktif</label>
                </div>
            </div>
            
              <div class="form-group">
                <label for="password">Password</label>
                <div class="input-group">
                    <input type="password" id="password" name="password" class="form-control" value="<?php echo e($user->password); ?>">
                    <span class="input-group-append">
                        <button class="btn btn-outline-secondary" type="button" id="togglePassword">
                            <i class="fas fa-eye" id="toggleIcon"></i>
                        </button>
                    </span>
                </div>
            </div>
            
            </div>
          </div>
          <!-- /.card -->
        </div>
        
        
      </div>
      <div class="row">
        <div class="col-12">
          
          
          <input type="submit" value="Simpan" class="btn btn-success float-right">
        </div>
      </div>
    </form>
    <script>
        document.getElementById('statusSwitch').addEventListener('change', function() {
            let statusLabel = document.querySelector('.custom-control-label');
            statusLabel.textContent = this.checked ? 'Aktif' : 'Nonaktif';
        });
    </script>
    <script>
      const togglePassword = document.getElementById('togglePassword');
      const password = document.getElementById('password');
      const toggleIcon = document.getElementById('toggleIcon');
  
      togglePassword.addEventListener('click', function () {
          const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
          password.setAttribute('type', type);
  
          // Change the icon
          toggleIcon.classList.toggle('fa-eye-slash');
      });
  </script>
  

  <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\edigitalsumenep\resources\views/admin/useredit.blade.php ENDPATH**/ ?>