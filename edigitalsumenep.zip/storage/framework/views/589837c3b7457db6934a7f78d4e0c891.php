
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    
      <section class="content-header">
      
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Produk Edit</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Produk</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>
<form action="<?php echo e(route('adminProduk.update',$produk->id)); ?>" method="post" enctype="multipart/form-data">
  <?php echo csrf_field(); ?>
  <?php echo method_field('put'); ?>
      <div class="row">
        <div class="col-md-6">
          <div class="card card-primary">
            <div class="card-header">
              <h3 class="card-title">Produk</h3>

              <div class="card-tools">
                <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                  <i class="fas fa-minus"></i>
                </button>
              </div>
            </div>
            <div class="card-body">
              
              <div class="form-group">
                <label for="inputName">Nama Produk</label>
                <input type="text" id="nama_produk" name="nama_produk" class="form-control" value="<?php echo e($produk->nama_produk); ?>">
              </div>
              <div class="form-group">
                <label for="inputName">Headline</label>
                <input type="text" id="inputName" name="tagline" class="form-control" value="<?php echo e($produk->tagline); ?>">
              </div>
              <div class="form-group">
                <label for="inputDescription">Produk Deskripsi</label>
                <textarea id="inputDescription" name="deskripsi" class="form-control" rows="4"><?php echo e($produk->deskripsi); ?></textarea>
              </div>
              <div class="form-group">
                <label for="exampleSelectRounded0">UMKM</label>
                <select class="custom-select rounded-0" id="exampleSelectRounded0" name="id_umkm">
                  <?php $__currentLoopData = $umkm; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($p->id); ?>" <?php echo e($produk->id_umkm == $p->id ? 'selected' : ''); ?>><?php echo e($p->nama); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
              
              </div>
              
            
              
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <div class="col-md-6">
          <div class="card card-secondary">
            <div class="card-header">
              <h3 class="card-title">Foto</h3>

              <div class="card-tools">
                <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                  <i class="fas fa-minus"></i>
                </button>
              </div>
            </div>
            <div class="card-body">
              
              <div class="form-group">
                <img src="/<?php echo e($produk->foto1); ?>" alt="Foto Awal" width="100">
                <label for="inputFotoProduk">Foto Produk Utama</label>
                <input type="file" id="inputFotoProduk" class="form-control" name="foto1" accept="assets\img\produk\">
            </div>
            
              <div class="form-group">
                <img src="/<?php echo e($produk->foto2); ?>" alt="Foto Awal" width="100">
                <label for="inputSpentBudget">Foto Produk Kedua</label>
                <input type="file" value="<?php echo e($produk->foto2); ?>" id="inputSpentBudget" name="foto2" class="form-control"  accept="assets\img\produk\">
              </div>
              <div class="form-group">
                <img src="/<?php echo e($produk->foto3); ?>" alt="Foto Awal" width="100">
                <label for="inputEstimatedDuration">Foto Produk ketiga</label>
                <input type="file" id="inputEstimatedDuration" name="foto3" class="form-control"  accept="assets\img\produk\">
              </div>
              
            
            </div>
            <!-- /.card-body -->
          </div>
          
          <!-- /.card -->
        </div>  
      </div>
      <div class="row">
        <div class="col-12">
          <input type="submit" value="Save Changes" class="btn btn-success float-right">
        </div>
      </div>
    </form>

  <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\edigitalsumenep\resources\views/admin/produkedit.blade.php ENDPATH**/ ?>