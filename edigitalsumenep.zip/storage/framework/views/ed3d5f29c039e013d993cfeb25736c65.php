
<?php $__env->startSection('container'); ?>

<section id="faq" class="faq">
    <div class="container-fluid" data-aos="fade-up">

      <div class="row gy-4">

        <div class="col-lg-7 d-flex flex-column justify-content-center align-items-stretch  order-2 order-lg-1">
          <div class="content px-xl-5">
            <h3 style="color: black">Tanya <strong>Jawab</strong></h3>
            <p>
              Berikut ini adalah beberapa panduan yang disusun untuk membantu UMKM memahami fungsi dari e-display
            </p>
          </div>

          <div class="accordion accordion-flush px-xl-5" id="faqlist">

            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="accordion-item" data-aos="fade-up" data-aos-delay="<?php echo e(($d->id * 100) +200); ?>">
              <h3 class="accordion-header">
                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq-content-<?php echo e($d->id); ?>">
                  <i class="bi bi-question-circle question-icon"></i>
                  <?php echo e($d->pertanyaan); ?>

                </button>
              </h3>
              <div id="faq-content-<?php echo e($d->id); ?>" class="accordion-collapse collapse" data-bs-parent="#faqlist">
                <div class="accordion-body">
                  <?php echo e($d->jawaban); ?>  </div>
              </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!-- # Faq item-->

           

          </div>

        </div>

        <div class="col-lg-5 align-items-stretch order-1 order-lg-2 img" style='background-image: url("assets/img/faq.jpg");'>&nbsp;</div>
      </div>

    </div>
  </section><!-- End F.A.Q Section -->
  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\edigitalsumenep\resources\views/bantuan.blade.php ENDPATH**/ ?>