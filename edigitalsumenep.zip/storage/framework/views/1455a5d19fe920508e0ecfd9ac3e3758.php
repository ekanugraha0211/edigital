
<?php $__env->startSection('container'); ?>
  <section id="portfolio" class="portfolio sections-bg">
    <div class="container" data-aos="fade-up">

      <div class="section-header">
        <h2>PRODUK UMKM SUMENEP</h2>
        <!-- <p>Quam sed id excepturi ccusantium dolorem ut quis dolores nisi llum nostrum enim velit qui ut et autem uia reprehenderit sunt deleniti</p> -->
      </div>

      

      <div class="portfolio-flters d-flex flex-row justify-content-center">
        <!-- Input pencarian menggunakan komponen form Bootstrap -->
        <input id="search-input" class="form-control me-2 w-75"  type="search" placeholder="Cari Produk" aria-label="Search">
      </select>
        <button id="search-button" class="btn btn-success" type="button">Cari</button>
      </div>
      
        
                           

      <section id="blog" class="blog">
        <div class="container" >
          
          <div class="row gy-4 posts-list">
            <?php $__empty_1 = true; $__currentLoopData = $produk->sortByDesc('id')->take(9); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            
            <div class="col-xl-4 col-md-6">
                <article class="post">
                  <div class="post-img" style="height: 200px; overflow: hidden;">
                    <img src="/<?php echo e($p->foto1); ?>" alt="Produk" class="img-fluid" style="width: 100%; height: 100%; object-fit: cover;">
                </div>
                
                    <p class="post-category">
                        <i class="bi bi-folder"></i> <?php echo e($p->umkm->sektorUsaha->nama); ?>

                    </p>
                    <h2 class="title">
                        <a href="<?php echo e(route('produkdetail', $p->id)); ?>"><?php echo e($p->nama_produk); ?></a>
                    </h2>
                    <div class="d-flex align-items-center">
                        <div class="post-author-img flex-shrink-0 rounded-circle" style="width: 50px; height: 50px;">
                            <img src="/<?php echo e($p->umkm->logo); ?>" alt="Logo UMKM" class="img-fluid" style="width: 100%; height: 100%; object-fit: cover; border-radius: 50%;">
                        </div>
                        <div class="post-meta ms-3">
                            <p class="post-author-list mb-0">
                                <i class="bi bi-person"></i> <?php echo e($p->umkm->nama); ?>

                            </p>
                            <p class="post-author-list mb-0">
                                <i class="bi bi-geo-alt"></i> <?php echo e($p->umkm->alamat); ?>

                            </p>
                        </div>
                    </div>
                </article>
            </div>
            
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col">
                <p>Produk tidak ditemukan.</p>
            </div>
            <?php endif; ?>
        </div>
        
  
        </div>
      </section><!-- End Portfolio Container -->

      </div>

    </div>
  </section><!-- End Portfolio Section -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\edigitalsumenep\resources\views/produk.blade.php ENDPATH**/ ?>