
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    
      <section class="content-header">
      
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Tambah UMKM</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">UMKM</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>
<form action="<?php echo e(route('adminUmkm.store')); ?>" method="post" enctype="multipart/form-data">
  <?php echo csrf_field(); ?>
  
      <div class="row">
        <div class="col-md-6">
          <div class="card card-primary">
            <div class="card-header">
              <h3 class="card-title">Data Primer</h3>
              

              <div class="card-tools">
                <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                  <i class="fas fa-minus"></i>
                </button>
              </div>
            </div>
            <div class="card-body">
              
                <div class="form-group">
                  <label for="nama">Nama UMKM</label>
                  <input type="text" id="nama" name="nama" class="form-control" >
              </div>
              <div class="form-group">
                
                <label for="inputEstimatedDuration">Logo</label>
                <input type="file" id="inputEstimatedDuration" name="logo" class="form-control"  accept="assets\img\produk\">
              </div>
              <div class="form-group">
                  <label for="alamat">Alamat</label>
                  <input type="text" id="alamat" name="alamat" class="form-control" >
              </div>
              <div class="form-group">
                  <label for="desa">Desa</label>
                  <input type="text" id="desa" name="desa" class="form-control" >
              </div>
              <div class="form-group">
                  <label for="kecamatan">Kecamatan</label>
                  <input type="text" id="kecamatan" name="kecamatan" class="form-control">
              </div>
              <div class="form-group">
                  <label for="kodepos">Kode Pos</label>
                  <input type="text" id="kodepos" name="kodepos" class="form-control">
              </div>
              <div class="form-group">
                  <label for="no_telp_kantor">Nomor Telepon Kantor</label>
                  <input type="text" id="no_telp_kantor" name="no_telp_kantor" class="form-control">
              </div>
              <div class="form-group">
                  <label for="website">Website</label>
                  <input type="text" id="website" name="website" class="form-control">
              </div>
              
              <div class="form-group">
                  <label for="whatsapp">Whatsapp</label>
                  <input type="text" id="whatsapp" name="whatsapp" class="form-control">
              </div>
              <div class="form-group">
                <label for="id_user">Users</label>
                <select class="custom-select rounded-0" id="id_user" name="id_user">
                  <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($p->id); ?>" ><?php echo e($p->name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>              
            </div>
              
              
              
              
            
              
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <div class="col-md-6">
          <div class="card card-primary">
            <div class="card-header">
              <h3 class="card-title">Data Sekunder</h3>

              <div class="card-tools">
                <button type="button" class="btn btn-tool" data-card-widget="collapse" title="Collapse">
                  <i class="fas fa-minus"></i>
                </button>
              </div>
            </div>
            <div class="card-body">
              <div class="form-group">
                  <label for="nomor_surat_ijin">Nomor Surat Ijin</label>
                  <input type="text" id="nomor_surat_ijin" name="nomor_surat_ijin" class="form-control" >
              </div>
             
              <div class="form-group">
                  <label for="faksimili">Faksimili</label>
                  <input type="text" id="faksimili" name="faksimili" class="form-control" >
              </div>
             
              <div class="form-group">
                  <label for="tgl_mulai">Tanggal Mulai</label>
                  <input type="date" id="tgl_mulai" name="tgl_mulai" class="form-control" >
              </div>
              <div class="form-group">
                  <label for="NPWP">NPWP</label>
                  <input type="text" id="NPWP" name="NPWP" class="form-control" >
              </div>
              
              <div class="form-group">
                  <label for="jumlah_karyawan_pria">Jumlah Karyawan Pria</label>
                  <input type="text" id="jumlah_karyawan_pria" name="jumlah_karyawan_pria" class="form-control" >
              </div>
              <div class="form-group">
                  <label for="jumlah_karyawan_wanita">Jumlah Karyawan Wanita</label>
                  <input type="text" id="jumlah_karyawan_wanita" name="jumlah_karyawan_wanita" class="form-control" >
              </div>
              <div class="form-group">
                  <label for="akses_perbankan">Akses Perbankan</label>
                  <input type="text" id="akses_perbankan" name="akses_perbankan" class="form-control" >
              </div>
              <div class="form-group">
                  <label for="modal_awal">Modal Awal</label>
                  <input type="text" id="modal_awal" name="modal_awal" class="form-control" >
              </div>
              <div class="form-group">
                  <label for="omset">Omset</label>
                  <input type="text" id="omset" name="omset" class="form-control" >
              </div>
              <div class="form-group">
                  <label for="id_bentuk_usaha">ID Bentuk Usaha</label>
                  <select class="custom-select rounded-0" id="id_bentuk_usaha" name="id_bentuk_usaha">
                    <?php $__currentLoopData = $bentuk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($p->id); ?>" ><?php echo e($p->nama); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>              
              </div>
              <div class="form-group">
                  <label for="id_sektor_usaha">ID Sektor Usaha</label>
                  <select class="custom-select rounded-0" id="exampleSelectRounded0" name="id_sektor_usaha">
                    <?php $__currentLoopData = $sektor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($p->id); ?>" ><?php echo e($p->nama); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>              
              </div>
              <div class="form-group">
                  <label for="id_skala_usaha">ID Skala Usaha</label>
                  <select class="custom-select rounded-0" id="exampleSelectRounded0" name="id_skala_usaha">
                    <?php $__currentLoopData = $skala; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($p->id); ?>" ><?php echo e($p->nama); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>              
              </div>
              
            
              
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        
        
      </div>
      <div class="row">
        <div class="col-12">
          
          
          <input type="submit" value="Save Changes" class="btn btn-success float-right">
        </div>
      </div>
    </form>

  <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\edigitalsumenep\resources\views/admin/umkmadd.blade.php ENDPATH**/ ?>